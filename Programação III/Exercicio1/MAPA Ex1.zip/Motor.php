	<?php
	class Motor extends Carro{

	  public $cilindro, $potencia, $giroAtual, $combustivel;
	}


	?>