	<form action="../Controller/dados.php" method="post">

	motor:<input type="text" name="motor">
	modelo:<input type="text" name = "modelo">
	cor:<input type"text" name="cor">
	marca:<input type"text" name ="marca">
	ano:<input type  "text" name ="ano">
	cambio:<input type "text" name ="cambio">

	cilindro:<input type="text" name = "cilindro">
	potencia:<input type="text" name = "potencia">
	giroAtual:<input type="text" name = "giroAtual">
	combustivel:<input type= "text" name = "combustivel">


	<input type="submit" value="Gravar">

	</form>